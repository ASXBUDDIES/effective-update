# bcii-tweetwall
A tweetwall designed specifically for UTS BCII scavenger hunts.
